import { combineReducers } from "redux";
import itemReducer from "./ItemSlice/itemReducers";

const rootReducers = combineReducers({
  item: itemReducer,
});

export default rootReducers;
